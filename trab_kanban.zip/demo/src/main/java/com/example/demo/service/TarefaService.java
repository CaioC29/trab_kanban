package com.example.demo.service;
import com.example.demo.model.Tarefa;
import org.springframework.stereotype.Service;
import com.example.demo.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class TarefaService {

    @Autowired
    private TarefaRepository tarefaRepository;


    public Tarefa findById(int id) {
        return tarefaRepository.findById(id).orElse(null);
    }

    public List<Tarefa> findAll() {
        return tarefaRepository.findAll();
    }

    public List<Tarefa> findByStatus(int n_stat) {
        List<Tarefa> listaTarefa = tarefaRepository.findAll();
        List<Tarefa> TarefaPorStatus = new ArrayList<>();

        String stat = switch (n_stat) {
            case 1 -> "Pendente";
            case 2 -> "Em andamento";
            case 3 -> "Concluída";
            default -> "";
        };

        String[] prioridade = {"Baixa", "Média", "Alta"};
        int i = 0;

        while(i <= 2){

            for (Tarefa tarefa : listaTarefa) {
                if(tarefa.getStatus().equals(stat) && tarefa.getPrioridade().equals(prioridade[i])) {
                    TarefaPorStatus.add(tarefa);
                }
            }
            i++;
        }

        if(TarefaPorStatus.isEmpty()) {
            return null;
        }

        return TarefaPorStatus;
    }

    public Tarefa save(Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }

    public void delete(int id) {
        tarefaRepository.deleteById(id);
        System.out.println("Tarefa "+ id +" excluída");
    }

    public void mover(int id){
        Tarefa tarefa = tarefaRepository.findById(id).orElse(null);
        if (tarefa == null){
            throw new RuntimeException("Essa tarefa não existe");
        }
        else{
            switch (tarefa.getStatus()) {
                case "Em andamento" -> {
                    tarefa.setStatus("Concluido");
                    System.out.println("Status alterado para: " + tarefa.getStatus());
                    tarefaRepository.save(tarefa);
                }
                case "Pendente" -> {
                    tarefa.setStatus("Em andamento");
                    System.out.println("Status alterado para: " + tarefa.getStatus());
                    tarefaRepository.save(tarefa);
                }

                default -> System.out.println("Tarefa concluída");
            }
        }
    }

    public Tarefa editarTarefa(int id, Tarefa newStuff){
        Tarefa tarefa = tarefaRepository.findById(id).orElse(null);
        if (tarefa == null){
            throw new RuntimeException("Essa tarefa não existe");
        }
        else{
            if(newStuff.getDescricao() != null){
                tarefa.setDescricao(newStuff.getDescricao());
            }
            if(newStuff.getData_criacao() != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                String dataFormatada = newStuff.getData_criacao().format(formatter);
                tarefa.setData_criacao(dataFormatada);
            }
            if(newStuff.getPrioridade() != null){
                tarefa.setPrioridade(newStuff.getPrioridade());
            }
            if(newStuff.getTitulo() != null){
                tarefa.setTitulo(newStuff.getTitulo());
            }

            return tarefaRepository.save(tarefa);
        }
    }

}