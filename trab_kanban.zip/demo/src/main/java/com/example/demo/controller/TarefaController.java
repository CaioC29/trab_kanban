package com.example.demo.controller;
import org.springframework.web.bind.annotation.*;
import com.example.demo.service.TarefaService;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.demo.model.Tarefa;
import java.util.List;

@RestController
@RequestMapping("/tarefa")
public class TarefaController {


    @GetMapping
    public List<Tarefa> listar(){
        return tarefaService.findAll();
    }


    @Autowired
    private TarefaService tarefaService;


    @PutMapping("/{id}/move")
    public Tarefa update(@PathVariable int id){
        tarefaService.mover(id);
        return tarefaService.findById(id);
    }

    @PostMapping
    public Tarefa add(@RequestBody Tarefa tarefa){
        return tarefaService.save(tarefa);
    }

    @DeleteMapping("/{id}")
    public String deletar(@PathVariable int id){
        Tarefa tarefa = tarefaService.findById(id);
        tarefaService.delete(id);
        return "Tarefa excluída: \n\n" + tarefa.toString();
    }

    @GetMapping("/{id}")
    public Tarefa listarById(@PathVariable int id){
        return tarefaService.findById(id);
    }


    @PutMapping("/{id}")
    public Tarefa edit(@PathVariable int id, @RequestBody Tarefa tarefa){
        return tarefaService.editarTarefa(id, tarefa);
    }

    @GetMapping("/filter/{stat}")
    public List<Tarefa> listarPorStatus(@PathVariable int stat){
        return tarefaService.findByStatus(stat);
    }

}